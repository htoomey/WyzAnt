/******************************************************************************
		   Vector and Matrix Norms - Algorithm 7.0B
*******************************************************************************

To compute all possible norms of the vector X or the matrix A.

INPUT dimension n; Vector X or matrix A.

OUTPUT Unit (1) Norm, Euclidean (2) Norm, and Infinity (�) norm.  Also the
Circle-one (1) Norm and Frobenius (F) Norm for matrices.

NOTE: This algorithm was included as a "Homework Helper."  See p. 393,
Exercise Set 7.1, Problems 1-10.

*******************************************************************************
*	Written by:  Harold A. Toomey, CARE-FREE SOFTWARE, 3Q 1991, v4.2      *
******************************************************************************/

#include "naautil.c"		/* Numerical Analysis Algorithms Utilities. */

char *outfile = "070b.out";	/* Customized default output file name.     */


main()
{
  double *X, **A, tmp;
  double Unit_Norm_X(), Euclidean_Norm_X(), Infinite_Norm_X();
  double Unit_Norm_A(), Euclidean_Norm_A(), Infinite_Norm_A();
  double Circle_One_Norm_A(), Frobenius_Norm_A(), power();
  int i, j, n, ch;

  /**********
   * INPUTS *
   **********/

  NAA_do_first(outfile);	/* NAA initialization procedure. */

  printf2("Vector and Matrix Norms - Algorithm 7.0B\n\n");

  printf("This program computes the Unit (1) Norm, Euclidean (2) Norm,\n");
  printf("and Infinity (�) Norm of vectors and matrices.  It also computes\n");
  printf("the Circle-one (1) Norm and Frobenius (F) Norm for matrices.\n\n");

  printf("Would you like all norms of a Vector or a Matrix? (V/M) M: ");
  ch = tolower(getchar());

  if (ch == 'v') {		/* Vector Norms */

    do {
      printf("Enter the dimension, n, of the vector X: ");
      scanf("%d", &n);
      if (n <= 0)
        printf("ERROR - n must be greter than zero.\n");
    } while (n <= 0);

    /* Dynamically allocate memory for the needed arrays. */
    X = dvector(1,n);		/* Vector X */

    printf("Enter the coefficients for matrix X:\n");	/* Get X. */
    for (i=1;i<=n;i++) {
      printf("\tX[%d] = ", i);
      scanf("%lf", &X[i]);
    }
    printf("\n");

    fprintf(file_id, "X = [ ");	/* Print vector X to file. */
    for (i=1;i<=n;i++)
      fprintf(file_id, "% .9lg ", X[i]);
    fprintf(file_id, "]t\n\n");

    /*************************
     * ALGORITHM AND OUTPUTS *
     *************************/

    printf2("The Unit (1) Norm      = %.9lg\n", Unit_Norm_X(X,n));
    printf2("The Euclidean (2) Norm = %.9lg\n", Euclidean_Norm_X(X,n));
    printf2("The Infinite (�) Norm  = %.9lg\n", Infinite_Norm_X(X,n));

    /* Free the memory that was dynamically allocated for the arrays. */
    free_dvector(X,1,n);

  } else {			/*  Matrix Norms (ch == 'm') */

    do {
      printf("Enter the dimension, n, of the matrix A: ");
      scanf("%d", &n);
      if (n <= 0)
        printf("ERROR - n must be greter than zero.\n");
    } while (n <= 0);

    /* Dynamically allocate memory for the needed arrays. */
    A = dmatrix(1,n,1,n);	/* Matrix A */

    printf("Enter the coefficients for matrix A:\n");	/* Get A. */
    for (i=1;i<=n;i++)
      for (j=1;j<=n;j++) {
        printf("\tA[%d][%d] = ", i, j);
        scanf("%lf", &A[i][j]);
      }
    printf("\n");

    fprintf(file_id, "A = ");	/* Print Matrix A to file. */
    for (i=1;i<=n;i++) {
      fprintf(file_id, "[ ");
      for (j=1;j<=n;j++)
        fprintf(file_id, "% .9lg ", A[i][j]);
      fprintf(file_id, "]\n    ");
    }
    fprintf(file_id, "\n");

    /*************************
     * ALGORITHM AND OUTPUTS *
     *************************/

    printf2("The Unit (1) Norm       = %.9lg\n", Unit_Norm_A(A,n));
    printf2("The Infinite (�) Norm   = %.9lg\n", Infinite_Norm_A(A,n));
    printf2("The Circle-One (1) Norm = %.9lg\n", Circle_One_Norm_A(A,n));
    printf2("The Frobenius (F) Norm  = %.9lg\n", Frobenius_Norm_A(A,n));
    if ((tmp = Euclidean_Norm_A(A,n)) != 0.0) 
      printf2("The Euclidean (2) Norm  = %.9lg\n", tmp);

    /* Free the memory that was dynamically allocated for the arrays. */
    free_dmatrix(A,1,n,1,n);
  }

  NAA_do_last(outfile);		/* NAA finish-up procedure. */

}				/* STOP */

/*****************************************************************************/
/* Unit_Norm_X() - Computes Unit Norm for a vector.                          */
/*****************************************************************************/
double Unit_Norm_X(X,n)
double *X;
int n;
{
  double sum = 0.0;
  int i;

  for (i=1;i<=n;i++)
    sum += fabs(X[i]);

  return (sum);
}

/*****************************************************************************/
/* Euclidean_Norm_X() - Computes Euclidean Norm for a vector.                */
/*****************************************************************************/
double Euclidean_Norm_X(X,n)
double *X;
int n;
{
  double sum_of_squares = 0.0;
  int i;

  for (i=1;i<=n;i++)
    sum_of_squares += pow(X[i], 2.0);

  return (sqrt(sum_of_squares));
}

/*****************************************************************************/
/* Infinite_Norm() - Computes Infinite Norm for a vector.                    */
/*****************************************************************************/
double Infinite_Norm_X(X,n)
double *X;
int n;
{
  double max = 0.0;
  int i;

  for (i=1;i<=n;i++)
    if (fabs(X[i]) > fabs(max))
      max = X[i];

  return (max);
}

/*****************************************************************************/
/* Unit_Norm_A() - Computes Unit Norm for a Matrix.  See text p.394, Prob. 7 */
/*****************************************************************************/
double Unit_Norm_A(A,n)
double **A;
int n;
{
  double max = 0.0, sum;
  int i, j;

  for (j=1;j<=n;j++) {
    sum = 0.0;
    for (i=1;i<=n;i++)		/* Sum the magnitudes of the jth column. */
      sum += fabs(A[i][j]);
    if (fabs(sum) > fabs(max))
        max = sum;
  }

  return (max);
}

/*****************************************************************************/
/* Euclidean_Norm_A() - Computes Euclidean Norm for a Matrix.                */
/*****************************************************************************/
double Euclidean_Norm_A(A,n)
double **A;
int n;

/*
** Note:
**   This algorithms uses the Power Method used in Algorithm 9.1.  It assumes
**   than the n x n matrix A has n eigenvalues lambda_1, lambda_2,...,lambda_n
**   with an associated collection of linearly independent eigenvectors { v(1),
**   v(2), v(3),...,v(n) }.  Moreover, we assume A has precisely one eigenvalue
**   that is largest in amplitude.  See p. 492 and Algorithm 9.1 on p. 494.
**
**   If the above conditions do not apply, then I recommend solving by hand.
**
**   FORMULA:  || A ||_2 = [rho(At*A)]^(1/2)
**
** How to solve by hand:
**
**   1.  Solve for the eigenvalues of At * A where At is A transpose:
**         0 = det( At * A - lambda * I )
**
**       Hint: Use Algorithm 2.8A - CPOLY to numerically solve for the
**             eigenvalues (roots) of the above polynomial.
**
**   2.  Determine the maximum eigenvalue (should be positive):
**         max = maximum { lambda_1, lambda_2, lambda_3, ..., lambda_n }
**
**   3.  Take the square root of max to solve for the Euclidean_Norm:
**         Euclidean_Norm = sqrt ( max )
*/

{
  double **ATA, tmp, power();
  int i, j, k;

  /* Dynamically allocate memory for the needed arrays. */
  ATA = dmatrix(1,n,1,n);	/* Matrix At * A                */

  /* FORMULA:  || A ||_2 = [rho(At*A)]^(1/2) */

  /* STEP #1 */
  for (i=1;i<=n;i++)		/* Multiply At by A to get ATA. */
    for (j=1;j<=n;j++) {
      tmp = 0.0;
      for (k=1;k<=n;k++)
        tmp += A[k][i] * A[k][j];
      ATA[i][j] = tmp;
    }

  /* STEP #2 */
  tmp = power(ATA,n);		/* Returns max eigenvalue of At * A.         */

  /* STEP #3 */
  if (tmp != 0.0) {		/* power() was successful.  Return solution. */
    free_dmatrix(ATA,1,n,1,n);
    return (sqrt(fabs(tmp)));

  } else {			/* Sorry, must be done by hand.             */

    printf2("The Euclidean (2) Norm  = DO BY HAND!\n\n");

    printf2("ATTENTION:\n");
    printf2("Numerical methods for calculating the Euclidean (2) Norm of\n");
    printf2("Matrix A have failed.  Solve by hand using the below steps:\n\n");

    printf2("FORMULA:  || A ||_2 = [rho(At*A)]^(1/2) from Theorem 7.16");
    printf2(" on p. 397\n\n");

    printf2("1.  Solve for the eigenvalues of At * A where At is A");
    printf2(" transpose:\n");
    printf2("      0 = det( At * A - lambda * I )\n\n");

    printf2("    Hint: Use Algorithm 2.8A - CPOLY to numerically solve for");
    printf2(" the\n");
    printf2("          eigenvalues (roots) of the above polynomial.\n\n");

    printf2("2.  Determine the maximum eigenvalue (should be positive):\n");
    printf2("      max = maximum { lambda_1, lambda_2, lambda_3, ...,");
    printf2(" lambda_n }\n\n");

    printf2("3.  Take the square root of max to solve for the");
    printf2(" Euclidean_Norm:\n");
    printf2("      Euclidean_Norm = sqrt ( max )\n\n");

    printf2("For your convenience, At*A =\n\n    ");

    for (i=1;i<=n;i++) {	/* Print At * A */
      printf2("[ ");
      for (j=1;j<=n;j++)
        printf2("% 3.9lg ", ATA);
      printf2("]\n    ");
    }
    printf2("\n");

    free_dmatrix(ATA,1,n,1,n);
    return (0.0);
  }
}

/*****************************************************************************/
/* power() - Power Method - Algorithm 9.1   Returns the dominant eigenvalue. */
/*           Returns 0.0 if method fails.  Used by Euclidean_Norm_A() above. */
/*****************************************************************************/
double power(A, n)
double **A;			/* n x n matrix A      */
int n;
{
  double *X, *Y, *TEMP;
  double ERR, xp, yp, mu;
  double Infinite_Norm_X();
  double TOL = 1.0e-8;		/* Desired tolerance (to 8 decimal palces) */
  int N = 500;			/* Maximum number of iterations            */
  int i, j, k;

  /* Dynamically allocate memory for the needed arrays. */
  X    = dvector(1,n);		/* Initial eigenvector X      */
  Y    = dvector(1,n);		/* Vector Y                   */
  TEMP = dvector(1,n);		/* Temporary matrix for error */

  for (i=1;i<=n;i++)		/* Best guess at the initial eigenvector */
    X[i] = 1.0;

  /* STEP #1 */
  k = 1;

  /* STEP #2 */
  xp = Infinite_Norm_X(X);

  /* STEP #3 */
  for (i=1;i<=n;i++)
    X[i] /= xp;

  /* STEP #4 */
  while (k <= N) {		/* Do Steps 5-11. */

    /* STEP #5 */
    for (i=1;i<=n;i++) {
      Y[i] = 0.0;
      for (j=1;j<=n;j++)
        Y[i] += A[i][j] * X[j];
    }

    /* STEPS #6 & #7 */		/* Error: Text should swap these steps. */
    yp = Infinite_Norm_X(Y,n);
    mu = yp;

    /* STEP #8 */
    if (yp == 0.0)
      return (0.0);

    /* STEP #9 */
    for (i=1;i<=n;i++)
      TEMP[i] = X[i] - Y[i] / yp;
    ERR = fabs(Infinite_Norm_X(TEMP,n));
    for (i=1;i<=n;i++)
      X[i] = Y[i] / yp;

    /* STEP #10 */
    if (ERR < TOL)
      return (mu);		/* STOP - Procedure completed successfully. */

    /* STEP #11 */
    k++;			/* k = k + 1. */

  }

  /* STEP #12 */		/* Procudure completed unseccessfully. */
  printf2("\nMaximum number of iterations (%d) exceeded in power()\n", N);
  printf2("used by Euclidean_Norm_A()\n");

  /* Free the memory that was dynamically allocated for the arrays. */
  free_dvector(Y,1,n);
  free_dvector(TEMP,1,n);

  return(0.0);			/* Procedure failed. */
}				/* STOP */

/*****************************************************************************/
/* Infinite_Norm_A() - Computes Infinite Norm for a Matrix.                  */
/*****************************************************************************/
double Infinite_Norm_A(A,n)
double **A;
int n;
{
  double max = 0.0, sum;
  int i, j;

  for (i=1;i<=n;i++) {
    sum = 0.0;
    for (j=1;j<=n;j++)		/* Sum the magnitudes of the ith row. */
      sum += fabs(A[i][j]);
    if (fabs(sum) > fabs(max))	/* Keep the largest sum.              */
        max = sum;
  }

  return (max);
}

/*****************************************************************************/
/* Circle_One_Norm_A() - Computes Circle-One Norm for a Matrix.  See text    */
/*                       p. 394 Prob 9.                                      */
/*****************************************************************************/
double Circle_One_Norm_A(A,n)
double **A;
int n;
{
  double sum = 0.0;
  int i, j;

  for (i=1;i<=n;i++)
    for (j=1;j<=n;j++)
      sum += fabs(A[i][j]);	/* Sum of magnitudes of each matrix element. */

  return (sum);
}

/*****************************************************************************/
/* Frobenius_Norm_A() - Computes Frobenius Norm for a Matrix.  See text      */
/*                      p. 394 Prob 10.                                      */
/*****************************************************************************/
double Frobenius_Norm_A(A,n)
double **A;
int n;
{
  double sum = 0.0;
  int i, j;

  for (i=1;i<=n;i++)
    for (j=1;j<=n;j++)
      sum += A[i][j] * A[i][j];	/* Sum of squares of each matrix element. */

  return (sqrt(sum));
}

/*****************************************************************************/
/*	Copyright (C) 1988-1991, Harold A. Toomey, All Rights Reserved.      */
/*****************************************************************************/
